package com.example.eadassignment;

public class LoginResponse {




}
